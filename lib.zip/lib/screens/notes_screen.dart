
import 'package:appwrite/appwrite.dart';
import 'package:flutter/material.dart';

import '../components/note_item.dart';
import '../components/note_input_dialog.dart';
import '../services/notes_service.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  List<Map<String, dynamic>> notes = [];
  final TextEditingController noteController =
      TextEditingController();

  Map<String, dynamic>? editingNote;
  bool loading = true;
  bool saving = false;
  String? error;

  @override
  void initState() {
    super.initState();
    loadNotes();
  }

  Future<void> loadNotes() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final result = await notesService.getNotes();

      if (!mounted) return;
      setState(() => notes = result);
    } catch (e) {
      if (!mounted) return;
      setState(() => error = e.toString());
      debugPrint('LOAD NOTES FAILED: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<bool> saveNote() async {
    final text = noteController.text.trim();

    if (text.isEmpty) {
      showMessage('Please enter a note.');
      return false;
    }

    if (saving) return false;

    setState(() => saving = true);

    try {
      if (editingNote == null) {
        final created = await notesService.addNote(text);

        if (!mounted) return false;
        setState(() => notes.insert(0, created));
        showMessage('Note saved to Appwrite.');
      } else {
        final id = editingNote!['id'] as String;
        final updated = await notesService.updateNote(id, text);

        if (!mounted) return false;

        setState(() {
          final index =
              notes.indexWhere((note) => note['id'] == id);

          if (index != -1) notes[index] = updated;
        });

        showMessage('Note updated.');
      }

      editingNote = null;
      noteController.clear();
      return true;
    } catch (e) {
      debugPrint('SAVE NOTE FAILED: $e');
      if (mounted) showMessage('Could not save note: $e');
      return false;
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> deleteNote(String id) async {
    try {
      await notesService.deleteNote(id);

      if (!mounted) return;
      setState(() {
        notes.removeWhere((note) => note['id'] == id);
      });

      showMessage('Note deleted.');
    } catch (e) {
      debugPrint('DELETE NOTE FAILED: $e');
      showMessage('Could not delete note: $e');
    }
  }

  void editNote(Map<String, dynamic> note) {
    editingNote = note;
    noteController.text = note['content']?.toString() ?? '';
    showNoteDialog();
  }

  void showNoteDialog() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => NoteInputDialog(
        controller: noteController,
        isEditing: editingNote != null,
        onSave: saveNote,
      ),
    );
  }

  @override
  void dispose() {
    noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            height: 100,
            color: Colors.blue,
            padding: const EdgeInsets.only(
              bottom: 15,
              left: 20,
              right: 20,
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'My Notes',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  onPressed: () {
                    editingNote = null;
                    noteController.clear();
                    showNoteDialog();
                  },
                  icon: const Icon(
                    Icons.add_circle,
                    color: Colors.white,
                    size: 34,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: loading
                ? const Center(
                    child: CircularProgressIndicator(),
                  )
                : error != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(error!),
                              const SizedBox(height: 12),
                              ElevatedButton(
                                onPressed: loadNotes,
                                child: const Text('Retry'),
                              ),
                            ],
                          ),
                        ),
                      )
                    : notes.isEmpty
                        ? const Center(
                            child: Text('No notes yet. Create one!'),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(15),
                            itemCount: notes.length,
                            itemBuilder: (context, index) {
                              return NoteItem(
                                note: notes[index],
                                onEdit: editNote,
                                onDelete: deleteNote,
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}